package com.example.project;

public class User {
    public int ID;
    public String Account;
    public String Password;
    public String Pay;
    public int Balance;

}
