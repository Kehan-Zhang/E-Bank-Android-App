package com.example.project;

public class Record {
    public int ID;
    public int Amount;
    public String Account;
    public String Detail;
    public String Time;
}
