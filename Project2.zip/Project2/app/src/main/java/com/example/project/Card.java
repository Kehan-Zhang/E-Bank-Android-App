package com.example.project;

public class Card {
    //public int ID;
    public String Account;
    public String Type;
    public String BankName;
    public String CardNumber;
    public String IDNumber;
    public String OwnerName;
    public int Credit;
}
